import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { PageLayout } from "@/components/PageLayout";
import { NewCreativeDrawerV2 } from "@/components/NewCreativeDrawerV2";
import { Plus } from "lucide-react";

export default function CreativeLibrary() {
  const { user } = useAuth();
  const [creatives, setCreatives] = useState<any[]>([]);
  const [campaigns, setCampaigns] = useState<Array<{ id: string; name: string }>>([]);
  const [loading, setLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    if (user) {
      fetchCreatives();
      fetchCampaigns();
    }
  }, [user]);

  const fetchCreatives = async () => {
    try {
      const { data, error } = await supabase
        .from("creatives")
        .select("id, name, creative_type, image_urls, created_at")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setCreatives(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCampaigns = async () => {
    try {
      const { data, error } = await supabase
        .from("campaigns")
        .select("id, name")
        .eq("user_id", user?.id)
        .order("name");

      if (error) throw error;
      setCampaigns(data || []);
    } catch (error: any) {
      console.error("Error fetching campaigns:", error);
    }
  };

  return (
    <PageLayout 
      title="Creative Library"
      action={
        <Button onClick={() => setDrawerOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Creative
        </Button>
      }
    >
      {loading ? (
        <p>Loading...</p>
      ) : creatives.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No creatives found</p>
          <Button onClick={() => setDrawerOpen(true)} className="mt-4">
            <Plus className="h-4 w-4 mr-2" />
            Add Your First Creative
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {creatives.map((creative) => (
            <div key={creative.id} className="border rounded-lg p-4 space-y-2">
              {creative.image_urls?.[0] && (
                <img 
                  src={creative.image_urls[0]} 
                  alt={creative.name} 
                  className="w-full h-48 object-cover rounded"
                />
              )}
              <p className="font-semibold truncate">{creative.name}</p>
              <p className="text-sm text-muted-foreground">{creative.creative_type}</p>
            </div>
          ))}
        </div>
      )}

      <NewCreativeDrawerV2
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onSuccess={fetchCreatives}
        campaigns={campaigns}
      />
    </PageLayout>
  );
}
